package com.chlqudco.develop.fastcampustheredcoroutine.api

import com.chlqudco.develop.fastcampustheredcoroutine.model.Item

data class ImageSearchResponse(
    val lastBuildDate: String,
    val total: Int,
    val start: Int,
    val display: Int,
    val items: List<Item>
)